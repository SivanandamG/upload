import { ADD_DATA } from "./actionTypes"

export const add_data = (payload)=>{
     return {type:ADD_DATA,payload:payload}
}